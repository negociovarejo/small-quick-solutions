#!/bin/sh

java FastUpdate
